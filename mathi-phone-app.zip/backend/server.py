from fastapi import FastAPI, APIRouter, HTTPException, Query
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import requests


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StatusCheckCreate(BaseModel):
    client_name: str


# Product Models
class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    model: str  # 11, 12, 13, 14, 15, 16, 17, se
    type: str  # pro-max, pro, plus, normal, mini, se
    storage: str  # 64GB, 128GB, 256GB, 512GB, 1TB
    color: str
    condition: str  # sealed, like-new, excellent, good
    battery_health: int  # 0-100
    price_ars: float
    price_usd: float
    screen_size: str
    chip: str
    camera: str
    features: List[str]
    available: bool = True
    warranty_months: int = 0
    description: str = ""
    image_url: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    name: str
    model: str
    type: str
    storage: str
    color: str
    condition: str
    battery_health: int
    price_ars: float
    price_usd: float
    screen_size: str
    chip: str
    camera: str
    features: List[str]
    available: bool = True
    warranty_months: int = 0
    description: str = ""
    image_url: str = ""

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    model: Optional[str] = None
    type: Optional[str] = None
    storage: Optional[str] = None
    color: Optional[str] = None
    condition: Optional[str] = None
    battery_health: Optional[int] = None
    price_ars: Optional[float] = None
    price_usd: Optional[float] = None
    screen_size: Optional[str] = None
    chip: Optional[str] = None
    camera: Optional[str] = None
    features: Optional[List[str]] = None
    available: Optional[bool] = None
    warranty_months: Optional[int] = None
    description: Optional[str] = None
    image_url: Optional[str] = None


# Exchange Rate Models
class ExchangeRates(BaseModel):
    usd: float = 1.0
    ars: float
    usdt: float = 1.0
    btc: float
    eth: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# Basic Routes
@api_router.get("/")
async def root():
    return {"message": "Mathi Phone API - Tu tienda Apple premium"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    
    _ = await db.status_checks.insert_one(doc)
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    
    for check in status_checks:
        if isinstance(check['timestamp'], str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    
    return status_checks


# Product Routes
@api_router.post("/products", response_model=Product)
async def create_product(product: ProductCreate):
    """Create a new product"""
    product_obj = Product(**product.model_dump())
    
    doc = product_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    await db.products.insert_one(doc)
    return product_obj

@api_router.get("/products", response_model=List[Product])
async def get_products(
    model: Optional[str] = Query(None, description="Filter by model (11, 12, 13, etc.)"),
    type: Optional[str] = Query(None, description="Filter by type (pro-max, pro, plus, etc.)"),
    condition: Optional[str] = Query(None, description="Filter by condition"),
    min_battery: Optional[int] = Query(None, description="Minimum battery health"),
    max_price_ars: Optional[float] = Query(None, description="Maximum price in ARS"),
    max_price_usd: Optional[float] = Query(None, description="Maximum price in USD"),
    available: Optional[bool] = Query(None, description="Filter by availability"),
    search: Optional[str] = Query(None, description="Search by name, model, or color")
):
    """Get all products with optional filters"""
    query = {}
    
    if model:
        query['model'] = model
    if type:
        query['type'] = type
    if condition:
        query['condition'] = condition
    if min_battery is not None:
        query['battery_health'] = {"$gte": min_battery}
    if max_price_ars is not None:
        query['price_ars'] = {"$lte": max_price_ars}
    if max_price_usd is not None:
        query['price_usd'] = {"$lte": max_price_usd}
    if available is not None:
        query['available'] = available
    if search:
        query['$or'] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"model": {"$regex": search, "$options": "i"}},
            {"color": {"$regex": search, "$options": "i"}},
            {"chip": {"$regex": search, "$options": "i"}}
        ]
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    
    for product in products:
        if isinstance(product.get('created_at'), str):
            product['created_at'] = datetime.fromisoformat(product['created_at'])
        if isinstance(product.get('updated_at'), str):
            product['updated_at'] = datetime.fromisoformat(product['updated_at'])
    
    return products

@api_router.get("/products/{product_id}", response_model=Product)
async def get_product(product_id: str):
    """Get a specific product by ID"""
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if isinstance(product.get('created_at'), str):
        product['created_at'] = datetime.fromisoformat(product['created_at'])
    if isinstance(product.get('updated_at'), str):
        product['updated_at'] = datetime.fromisoformat(product['updated_at'])
    
    return product

@api_router.put("/products/{product_id}", response_model=Product)
async def update_product(product_id: str, product_update: ProductUpdate):
    """Update a product"""
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    update_data = product_update.model_dump(exclude_unset=True)
    if update_data:
        update_data['updated_at'] = datetime.now(timezone.utc).isoformat()
        await db.products.update_one({"id": product_id}, {"$set": update_data})
    
    updated_product = await db.products.find_one({"id": product_id}, {"_id": 0})
    
    if isinstance(updated_product.get('created_at'), str):
        updated_product['created_at'] = datetime.fromisoformat(updated_product['created_at'])
    if isinstance(updated_product.get('updated_at'), str):
        updated_product['updated_at'] = datetime.fromisoformat(updated_product['updated_at'])
    
    return updated_product

@api_router.delete("/products/{product_id}")
async def delete_product(product_id: str):
    """Delete a product"""
    result = await db.products.delete_one({"id": product_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return {"message": "Product deleted successfully"}


# Exchange Rates Route
@api_router.get("/exchange-rates", response_model=ExchangeRates)
async def get_exchange_rates():
    """Get current exchange rates for USD, ARS, USDT, BTC, ETH"""
    try:
        # Get crypto prices from CoinGecko (free API, no key needed)
        crypto_response = requests.get(
            "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd",
            timeout=5
        )
        crypto_data = crypto_response.json()
        
        # Get ARS exchange rate from a free API
        try:
            ars_response = requests.get("https://api.exchangerate-api.com/v4/latest/USD", timeout=5)
            ars_data = ars_response.json()
            ars_rate = ars_data['rates'].get('ARS', 1000.0)
        except:
            ars_rate = 1000.0  # Fallback rate
        
        rates = ExchangeRates(
            usd=1.0,
            ars=ars_rate,
            usdt=crypto_data.get('tether', {}).get('usd', 1.0),
            btc=crypto_data.get('bitcoin', {}).get('usd', 50000.0),
            eth=crypto_data.get('ethereum', {}).get('usd', 3000.0)
        )
        
        return rates
    except Exception as e:
        logger.error(f"Error fetching exchange rates: {e}")
        # Return fallback rates
        return ExchangeRates(
            usd=1.0,
            ars=1000.0,
            usdt=1.0,
            btc=50000.0,
            eth=3000.0
        )


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()