import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const api = {
  // Products
  getProducts: async (filters = {}) => {
    const params = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key] !== null && filters[key] !== undefined && filters[key] !== '') {
        params.append(key, filters[key]);
      }
    });
    const response = await axios.get(`${API}/products?${params.toString()}`);
    return response.data;
  },
  
  getProduct: async (id) => {
    const response = await axios.get(`${API}/products/${id}`);
    return response.data;
  },
  
  createProduct: async (product) => {
    const response = await axios.post(`${API}/products`, product);
    return response.data;
  },
  
  updateProduct: async (id, product) => {
    const response = await axios.put(`${API}/products/${id}`, product);
    return response.data;
  },
  
  deleteProduct: async (id) => {
    const response = await axios.delete(`${API}/products/${id}`);
    return response.data;
  },
  
  // Exchange rates
  getExchangeRates: async () => {
    const response = await axios.get(`${API}/exchange-rates`);
    return response.data;
  }
};

export default api;