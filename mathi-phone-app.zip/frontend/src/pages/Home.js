import React, { useState, useEffect } from 'react';
import Hero from '../components/Hero';
import Categories from '../components/Categories';
import SearchBar from '../components/SearchBar';
import FilterSection from '../components/FilterSection';
import ProductCard from '../components/ProductCard';
import Contact from '../components/Contact';
import { api } from '../utils/api';

const Home = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    model: 'all',
    type: 'all',
    condition: 'all',
    battery: 'all'
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [products, filters, searchQuery]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const data = await api.getProducts();
      setProducts(data);
      setFilteredProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...products];

    // Apply model filter
    if (filters.model !== 'all') {
      filtered = filtered.filter(p => p.model === filters.model);
    }

    // Apply type filter
    if (filters.type !== 'all') {
      filtered = filtered.filter(p => p.type === filters.type);
    }

    // Apply condition filter
    if (filters.condition !== 'all') {
      filtered = filtered.filter(p => p.condition === filters.condition);
    }

    // Apply battery filter
    if (filters.battery !== 'all') {
      switch (filters.battery) {
        case '90-100':
          filtered = filtered.filter(p => p.battery_health >= 90);
          break;
        case '80-89':
          filtered = filtered.filter(p => p.battery_health >= 80 && p.battery_health < 90);
          break;
        case '70-79':
          filtered = filtered.filter(p => p.battery_health >= 70 && p.battery_health < 80);
          break;
        case 'below-70':
          filtered = filtered.filter(p => p.battery_health < 70);
          break;
        default:
          break;
      }
    }

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.model.toLowerCase().includes(query) ||
        p.color.toLowerCase().includes(query) ||
        p.chip.toLowerCase().includes(query) ||
        p.storage.toLowerCase().includes(query)
      );
    }

    setFilteredProducts(filtered);
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  return (
    <div className="home-page" data-testid="home-page">
      <Hero />
      <Categories />
      
      <section className="catalog-section" id="catalog" data-testid="catalog-section">
        <div className="catalog-container">
          <div className="catalog-header">
            <h2 className="catalog-title" data-testid="catalog-title">Catálogo de iPhones</h2>
            <p className="catalog-subtitle">
              Explora nuestra completa colección de iPhones. Desde el modelo más económico hasta el más potente.
            </p>
          </div>

          <SearchBar searchQuery={searchQuery} onSearchChange={setSearchQuery} />
          
          <FilterSection filters={filters} onFilterChange={handleFilterChange} />

          {loading ? (
            <div className="loading-container" data-testid="loading-container">
              <div className="loading-spinner"></div>
              <p>Cargando productos...</p>
            </div>
          ) : (
            <>
              <div className="products-count" data-testid="products-count">
                {filteredProducts.length} {filteredProducts.length === 1 ? 'producto encontrado' : 'productos encontrados'}
              </div>
              
              <div className="products-grid" data-testid="products-grid">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  <div className="no-products" data-testid="no-products">
                    <p>🔍 No se encontraron productos con los filtros seleccionados</p>
                    <button 
                      className="btn-reset-filters" 
                      onClick={() => {
                        setFilters({
                          model: 'all',
                          type: 'all',
                          condition: 'all',
                          battery: 'all'
                        });
                        setSearchQuery('');
                      }}
                      data-testid="btn-reset-filters"
                    >
                      Limpiar filtros
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </section>

      <Contact />
    </div>
  );
};

export default Home;